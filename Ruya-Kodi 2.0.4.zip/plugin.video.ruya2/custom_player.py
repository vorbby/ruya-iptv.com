# -*- coding: utf-8 -*-
import os
import sys
import re
import urlparse
import urllib
import urllib2
import time
import xbmc
import xbmcgui
import plugintools
class CustomPlayer(xbmc.Player):
 def __init__(self,*args,**kwargs):
  pass
  xbmc.Player.__init__(self)
  self.current_time=0
  self.total_time=0
  self.listener=None
  self.seek_pos=0
 def play_stream(self,url): 
  pass
  self.play(url)
 def play_item(self,item,pos=0): 
  pass
  xbmc_listitem=xbmcgui.ListItem(label=item.title,iconImage=item.thumbnail,thumbnailImage=item.thumbnail,path=item.url)
  xbmc_listitem.setInfo("video",{"Title":item.title,"Plot":item.plot})
  xbmc_listitem.setProperty('fanart_image',item.fanart)
  self.seek_pos=pos
  self.play(item.url,xbmc_listitem)
 def set_listener(self,listener): 
  pass
  self.listener=listener
 def onPlayBackStarted(self):
  pass
  if self.seek_pos>0:
   self.seekTime(self.seek_pos)
  while self.isPlaying():
   self.current_time=self.getTime()
   self.total_time=self.getTotalTime()
   xbmc.sleep(2000)
 def onPlayBackEnded(self):
  pass
  if self.listener is not None:
   self.listener.on_playback_ended()
 def onPlayBackStopped(self):
  pass
  if self.listener is not None:
   self.listener.on_playback_stopped()
 def onPlayBackPaused(self):
  pass
 def onPlayBackResumed(self):
  pass
 def onPlayBackSeek(self,time,seekOffset):
  pass
 def onPlayBackSeekChapter(self,seekChaper):
  pass
 def onPlayBackSpeedChanged(self,speed):
  pass
 def onQueueNextItem(self):
  pass
 def get_current_time(self):
  return self.current_time
 def get_total_time(self):
  return self.total_time
def play(url):
 pass
 player=CustomPlayer()
 player.PlayStream(url)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
