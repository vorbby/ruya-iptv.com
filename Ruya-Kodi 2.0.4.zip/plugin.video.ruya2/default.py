# -*- coding: utf-8 -*-
import os
import plugintools
import navigation
import api
from api import UserException
from item import Item
plugintools.application_log_enabled=(plugintools.get_setting("debug")=="true")
plugintools.module_log_enabled=(plugintools.get_setting("debug")=="true")
plugintools.http_debug_log_enabled=(plugintools.get_setting("debug")=="true")
pass
def start():
 if plugintools.get_setting("server")=="" or plugintools.get_setting("username")=="" or plugintools.get_setting("password")=="":
  plugintools.open_settings_dialog()
  if plugintools.get_setting("server")=="" or plugintools.get_setting("username")=="" or plugintools.get_setting("password")=="":
   return
 response=api.login()
 if response["error"]:
  plugintools.message(response["error_message"])
  plugintools.set_setting("password","")
  return
 if plugintools.get_setting("allow_adult")=="2":
  plugintools.set_setting("allow_adult","0")
 plugintools.set_setting("update_checked","false")
 item=Item(action="mainlist",view="menu")
 try:
  itemlist=navigation.get_next_items(item)
  window=navigation.get_window_for_item(item)
  window.setParentItem(item)
  window.setItemlist(itemlist)
  navigation.push_window(window)
  window.doModal()
  del window
 except UserException,e:
  import xbmcgui
  xbmcgui.Dialog().ok("Error",e.value)
start()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
