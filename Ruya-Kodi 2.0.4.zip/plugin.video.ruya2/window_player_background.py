# -*- coding: utf-8 -*-
import os
import sys
import urlparse,urllib,urllib2
import threading
import time
import random
import xbmc
import xbmcgui
import xbmcaddon
import windowtools
from windowtools import*
from item import Item
import plugintools
import navigation
import custom_player
class PlayerWindowBackground(xbmcgui.WindowXML):
 def __init__(self,xml_name,fallback_path):
  pass
  self.itemlist=None
  self.parent_item=None
  self.first_time=True
 def setParentItem(self,item):
  self.parent_item=item
 def setItemlist(self,itemlist):
  pass
  self.itemlist=[]
  for item in itemlist:
   pass
   self.itemlist.append(item)
 def onInit(self):
  pass
  if self.itemlist is None:
   next_items=navigation.get_next_items(self.parent_item)
   self.setItemlist(next_items)
  if self.first_time:
   self.first_time=False
   import window_player_live
   window=window_player_live.PlayerLiveWindow("player_live.xml",plugintools.get_runtime_path())
   window.setItemlist(self.itemlist)
   window.setParentItem(self.parent_item)
   window.set_current_channel_id(plugintools.get_setting("last_channel_id"))
   window.doModal()
   del window
   self.close()
 def onAction(self,action):
  pass
  if action==ACTION_PARENT_DIR or action==ACTION_PREVIOUS_MENU or action==ACTION_PREVIOUS_MENU2 or action==ACTION_STOP:
   self.close()
 def onFocus(self,control_id):
  pass
  pass
 def onClick(self,control_id):
  pass
  pass
 def onControl(self,control):
  pass
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
