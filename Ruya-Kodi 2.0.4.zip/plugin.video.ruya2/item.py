# -*- coding: utf-8 -*-
import base64
import urllib
import copy
class Item(object): 
 def __contains__(self,m):
  return m in self.__dict__
 def __init__(self,**kwargs): 
  kwargs.setdefault("title","")
  kwargs.setdefault("plot","")
  kwargs.setdefault("url","")
  kwargs.setdefault("thumbnail","")
  kwargs.setdefault("fanart","")
  kwargs.setdefault("action","")
  kwargs.setdefault("extra","")
  kwargs.setdefault("view","navigate")
  kwargs.setdefault("director","")
  kwargs.setdefault("writer","")
  kwargs.setdefault("rating","")
  kwargs.setdefault("runtime","")
  kwargs.setdefault("genre","")
  kwargs.setdefault("year","")
  kwargs.setdefault("folder",True)
  self.__dict__.update(kwargs)
 def tostring(self):
  return ", ".join([var+"=["+str(self.__dict__[var])+"]" for var in sorted(self.__dict__)]) 
 def tourl(self):
  return urllib.quote(base64.b64encode(plugintools.dump_json(self.__dict__)))
 def fromurl(self,url):
  STRItem=base64.b64decode(urllib.unquote(url))
  JSONItem=plugintools.load_json(STRItem)
  self.__dict__.update(JSONItem)
  return self
 def tojson(self,path=""): 
  if path:
   open(path,"wb").write(plugintools.dump_json(self.__dict__,indent=4,sort_keys=True))
  else:
   return plugintools.dump_json(self.__dict__,indent=4,sort_keys=True)
 def fromjson(self,STRItem={},path=""):
  if path:
   if os.path.exists(path):
    STRItem=open(path,"rb").read()
   else:
    STRItem={}
  JSONItem=plugintools.load_json(STRItem)
  self.__dict__.update(JSONItem)
  return self
 def clone(self,**kwargs):
  newitem=copy.deepcopy(self)
  newitem.__dict__.update(kwargs)
  return newitem
# Created by pyminifier (https://github.com/liftoff/pyminifier)
